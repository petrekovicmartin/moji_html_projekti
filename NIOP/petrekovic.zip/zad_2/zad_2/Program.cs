﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("unesi radijus:");
            string unos = Console.ReadLine();
            int r = int.Parse(unos);

            double ops = 2 * r * Math.PI;
            double pov = r * r * Math.PI;

            double pi = Math.PI;
            Console.WriteLine("konstanta je:{0}\nopseg je:{1}\npovršina je:{2}", pi, ops, pov);
            Console.ReadLine();

        }
    }
}
