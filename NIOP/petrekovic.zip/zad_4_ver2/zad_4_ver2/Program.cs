﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_4_ver2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("unesi milimetre:");
            string unos = Console.ReadLine();
            int mm = int.Parse(unos);
            int n = 6;
           int km = mm;
            while (n > 0)
            {
                km = km * 10;
                Console.WriteLine("pretvorba:{0}", km);
                n = n - 1;
            }
            Console.WriteLine("unesi kilometre:");
            string unos2 = Console.ReadLine();
            int km2 = int.Parse(unos2);
            km = km2;

            n = 6;
            while (n > 0)
            {
                km = km * 10;
                Console.WriteLine("pretvorba nazad:{0}", km);
                n = n - 1;
            }
            Console.ReadLine();
        }
    }
}
