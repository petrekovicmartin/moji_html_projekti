﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("unesi katetu a");
            string unos = Console.ReadLine();
            int ka = int.Parse(unos);

            Console.WriteLine("unesi katetu b");

            string unos2 = Console.ReadLine();
            int kb = int.Parse(unos2);

            double hip = Math.Sqrt((ka * ka) + (kb * kb));
            double pov = (ka * kb) / 2.0;
            if (ka > kb) Console.WriteLine("Duljina hipotenuze je:{0}", hip);
            if (kb > ka) Console.WriteLine("b kateta je dulja, ne ispisujem hipotenuzu");
            if (kb == ka) Console.WriteLine("duljina kateta a:{0}\nduljina katete b:{1}\nduljina hipotenuze:{2}\npovršina:{3}", ka, kb, hip, pov);
            Console.ReadLine();
        }
    }
}
