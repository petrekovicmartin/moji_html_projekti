﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("upiši svoj broj:");
            string unos = Console.ReadLine();
            double a = double.Parse(unos);
            double a1 = Math.Floor( a + 1);
            double a2 = Math.Floor( a - 1);
            if (a < 0) Console.WriteLine("sljedbenik upisanog broja je:{0}", a1);
            if (a>0) Console.WriteLine("prethodnik upisanog broja je:{0}", a2);
            Console.ReadLine();

        }
    }
}
