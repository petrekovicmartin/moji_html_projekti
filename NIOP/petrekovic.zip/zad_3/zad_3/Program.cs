﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace zad_3
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("unesi broj a");
            string unos = Console.ReadLine();
            int a = int.Parse(unos);

            Console.WriteLine("unesi broj c");
            string unos2 = Console.ReadLine();
            int b = int.Parse(unos2);

            Console.WriteLine("unesi broj b");
            string unos3 = Console.ReadLine();
            int c = int.Parse(unos3);
            int mini=Math.Min(a,Math.Min(b,c));
            int maxi=Math.Max(a,Math.Max(b,c));
            int srednji = 0;
            if (a > b && a < c) srednji = a;
            if (a > c && a < b) srednji = a;

            if (b > a && b < c) srednji = b;
            if (b > c && b < a) srednji = b;

            if (c > b && c < a) srednji = c;
            if (c > a && c < b) srednji = c;




            Console.WriteLine("najmanji:{0}\nnajveci:{1}\nsrednji:{2}",mini,maxi,srednji);
            Console.ReadLine();

        }
    }
}
